f1 <- function(x) {
  1
}
f2 <- function(x) {
  x * 2
}
f3 <- function(x) {
  x * 3
}
