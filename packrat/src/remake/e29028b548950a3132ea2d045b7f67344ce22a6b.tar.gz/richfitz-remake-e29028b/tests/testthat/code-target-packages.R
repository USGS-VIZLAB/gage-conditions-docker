## This will return TRUE if devtools is loaded
test_loaded <- function() {
  exists("install_github")
}
