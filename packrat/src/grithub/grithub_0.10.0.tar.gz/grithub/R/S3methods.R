#' @import yaml
## print.github <- function(x, ...) sapply(x$content, function(x) cat(as.yaml(x[names(x) != "body"]), cat(x$body)))

